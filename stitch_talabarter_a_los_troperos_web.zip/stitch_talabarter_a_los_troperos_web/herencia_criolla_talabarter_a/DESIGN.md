---
name: Herencia Criolla & Talabartería
colors:
  surface: '#fcf9f3'
  surface-dim: '#dcdad4'
  surface-bright: '#fcf9f3'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f6f3ed'
  surface-container: '#f0eee8'
  surface-container-high: '#ebe8e2'
  surface-container-highest: '#e5e2dc'
  on-surface: '#1c1c18'
  on-surface-variant: '#56423e'
  inverse-surface: '#31312d'
  inverse-on-surface: '#f3f0ea'
  outline: '#8a726d'
  outline-variant: '#ddc0bb'
  surface-tint: '#a03f2f'
  primary: '#651308'
  on-primary: '#ffffff'
  primary-container: '#842a1c'
  on-primary-container: '#ff9f8e'
  inverse-primary: '#ffb4a6'
  secondary: '#7e562e'
  on-secondary: '#ffffff'
  secondary-container: '#fdc796'
  on-secondary-container: '#79512a'
  tertiary: '#413000'
  on-tertiary: '#ffffff'
  tertiary-container: '#5d4600'
  on-tertiary-container: '#dfb33e'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffdad4'
  primary-fixed-dim: '#ffb4a6'
  on-primary-fixed: '#400200'
  on-primary-fixed-variant: '#81281a'
  secondary-fixed: '#ffdcbf'
  secondary-fixed-dim: '#f1bc8c'
  on-secondary-fixed: '#2d1600'
  on-secondary-fixed-variant: '#633f19'
  tertiary-fixed: '#ffdf98'
  tertiary-fixed-dim: '#eec14b'
  on-tertiary-fixed: '#251a00'
  on-tertiary-fixed-variant: '#5a4300'
  background: '#fcf9f3'
  on-background: '#1c1c18'
  surface-variant: '#e5e2dc'
  cuero-habano: '#3E2723'
  cuero-suela: '#A05A2C'
  cuero-crudo: '#EADECE'
  bordo-profundo: '#5A1215'
  bronce-envejecido: '#9E783B'
  plata-alpaca: '#D8DCD6'
  carbon-charcoal: '#1C1917'
typography:
  display:
    fontFamily: Playfair Display
    fontSize: 3.5rem
    fontWeight: '600'
    lineHeight: 4rem
    letterSpacing: -0.02em
  display-mobile:
    fontFamily: Playfair Display
    fontSize: 2.5rem
    fontWeight: '600'
    lineHeight: 3rem
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Playfair Display
    fontSize: 2.5rem
    fontWeight: '600'
    lineHeight: 3rem
    letterSpacing: -0.01em
  headline-lg-mobile:
    fontFamily: Playfair Display
    fontSize: 1.875rem
    fontWeight: '600'
    lineHeight: 2.375rem
  headline-md:
    fontFamily: Playfair Display
    fontSize: 1.75rem
    fontWeight: '600'
    lineHeight: 2.25rem
  headline-sm:
    fontFamily: Playfair Display
    fontSize: 1.25rem
    fontWeight: '600'
    lineHeight: 1.75rem
  title-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 1.125rem
    fontWeight: '600'
    lineHeight: 1.625rem
  title-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 1rem
    fontWeight: '600'
    lineHeight: 1.5rem
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 1.125rem
    fontWeight: '400'
    lineHeight: 1.75rem
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 0.9375rem
    fontWeight: '400'
    lineHeight: 1.5rem
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 0.8125rem
    fontWeight: '400'
    lineHeight: 1.25rem
  label-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 0.875rem
    fontWeight: '600'
    lineHeight: 1.25rem
    letterSpacing: 0.04em
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 0.75rem
    fontWeight: '600'
    lineHeight: 1rem
    letterSpacing: 0.06em
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 0.6875rem
    fontWeight: '700'
    lineHeight: 0.875rem
    letterSpacing: 0.08em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-mobile: 1rem
  margin: 3rem
  margin-mobile: 1.25rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system expresses a refined Argentine equestrian and artisanal heritage. It marries the timeless craftsmanship of bespoke saddlery, raw hide, and saddle stitchery with modern, luxury e-commerce clarity. The aesthetic avoids folkloric cliché or rustic disarray; instead, it establishes an elevated, tactile experience reminiscent of bespoke bootmakers and heritage leather houses.

### Personality & Core Attributes
- **Noble & Authentic:** Honest, tactile, grounded in pasture and workshop traditions.
- **Mastery & Craftsmanship:** Evoking the scent of tanned leather, beeswax, hand-forged alpaca silver, and precise saddle stitching.
- **Understated Luxury:** Confident, deliberate spacing with rich, organic textures rather than excessive digital effects.
- **Timeless Balance:** Historic, literary serif titles anchored by impeccably crisp, functional technical body copy.

### Design Movement & Aesthetic
The style blends **Tactile Heritage** with **Warm Organic Minimalism**. Physical depth is represented through warm cream foundations, rich leather tones, subtle debossed contours, and fine dashed borders evoking genuine hand-stitch detailing.

## Colors

The palette is rooted in the natural curing, dyeing, and metallurgic processes of traditional pampean saddlery.

### Core Roles
- **Primary (`#842A1C` - Borravino / Tanned Oxblood):** Used for primary CTAs, active states, key emphasis, and brand identity anchors. Derived from traditional dyed leather and aged wine tones.
- **Secondary (`#8C6239` - Cuero Tostado):** Used for sub-navigation, supporting structural frames, category headers, and tactile tags.
- **Tertiary (`#C59B27` - Oro Viejo / Bronce Bruñido):** Accents, ratings, seal emblems, badges of craftsmanship, and delicate highlights.
- **Neutral (`#F9F6F0` - Pergamino Claro):** Warm, unbleached canvas base, reflecting untreated vegetable-tanned fibers and archival parchment.

### Named Specialty Accents
- `cuero-habano` (`#3E2723`): High-contrast typography and deep framing.
- `cuero-crudo` (`#EADECE`): Secondary card containers and surface tier backgrounds.
- `bordo-profundo` (`#5A1215`): Hover states on primary interactive elements and alert highlights.
- `plata-alpaca` (`#D8DCD6`): Subtle metallic borders and divider lines representing silver criollo fittings.

## Typography

The typographic hierarchy pairs classical high-contrast serif headlines with utilitarian, ultra-clean grotesque sans-serifs for commerce and navigation.

- **Headlines & Editorial Statements (`Playfair Display`):** Carries the prestige, legacy, and literary weight of historic Argentine estancias. Use italicized variations selectively for craftsmanship notes, quotes, or product origins (e.g., *"Cinchado a mano en San Antonio de Areco"*).
- **Body & Functional Data (`Plus Jakarta Sans`):** Ensures clear legibility for dimensions, hide grain descriptions, shipping guides, and currency figures.
- **Labels, Badges & Prices:** Set in uppercase with wide tracking (`letterSpacing: 0.06em` to `0.08em`) to mimic metal stamps, hot-iron brands, and leather punches.

## Layout & Spacing

The layout is built upon a 12-column grid on desktop and tablet, collapsing into a 4-column system on mobile. 

### Grid Philosophy
- Generous outer margins convey luxury catalog framing; negative space honors the expansive feeling of the pampas landscape.
- Content sections alternate between open canvas arrangements and structured masonry or asymmetric showcases (e.g., full-height saddle hero imagery offset against two-column artisan details).
- Maximum layout width is capped at 1440px to prevent visual stretching on ultra-wide screens.

### Responsive Breakpoints
- **Mobile (< 768px):** 4 columns, `margin-mobile: 1.25rem`, `gutter-mobile: 1rem`. Sticky bottom actions for quick purchase and bespoke inquiry.
- **Tablet (768px – 1024px):** 8 columns, `margin: 2rem`, `gutter: 1.25rem`.
- **Desktop (> 1024px):** 12 columns, `margin: 3rem`, `gutter: 1.5rem`.

## Elevation & Depth

Rather than synthetic blur layers or neon glow drops, depth is established through tonal layering, embossed debossing cues, and warm umber ambient shadows.

### Surface Tiers
- **Base Canvas:** Neutral `#F9F6F0` (light cream pergamino).
- **Surface Tier 1 (Cards, Product Tiles):** Solid `#FFFFFF` or `#F4EFE6` (raw parchment), lifted by a fine 1px border in `#EADECE` (cuero crudo) or `#D8DCD6` (alpaca).
- **Surface Tier 2 (Floating Sheets, Modals, Flyouts):** `#FFFFFF` with an ambient warm shadow: `0 12px 32px -4px rgba(62, 39, 35, 0.08), 0 4px 12px -2px rgba(62, 39, 35, 0.04)`.

### Craft Details & Borders
- **Hand-Stitch Accent Borders:** Sub-containers and bespoke badges feature a decorative inner border rule styled with a subtle dash (`border: 1px dashed #A05A2C55`).
- **Debossed Metal & Leather Effect:** Selected badges or pressed seals incorporate an inset micro-shadow: `inset 0 1px 2px rgba(0, 0, 0, 0.12)`.

## Shapes

The design system uses deliberate, disciplined corners (`0.25rem` / `4px` base) evocative of beveled, cut leather and hand-tailored strapping. Pill-shaped circular extremes are reserved exclusively for compact status tags, artisan seal roundels, and floating counter chips.

- **Base Radius (Buttons, Inputs, Cards):** `0.25rem` (soft, tailored corner).
- **Medium Radius (Modals, Large Hero Panels):** `0.5rem` (`rounded-lg`).
- **Pills / Circles:** Reserved for round product swatches (leather types, metal finishes) and small circular seal emblems.

## Components

### Buttons
- **Primary:** Solid `#842A1C` background, `#FFFFFF` text, `0.25rem` radius. Hover shifts to `#5A1215` with subtle elevation. Typography is uppercase `label-lg` with slight tracking.
- **Secondary:** Transparent background with a 1.5px solid `#8C6239` border, `#3E2723` text. Hover fills with `#EADECE33`.
- **Artisanal Action (Bespoke / Custom Order):** `#3E2723` background with dual micro-trim border in `#9E783B` and gold-toned serif label.

### Cards & Product Tiles
- Built with a `#FFFFFF` base on the cream background.
- Crisp 1px border using `#EADECE`.
- Imagery uses natural photography with warm lighting; hover initiates a slow, calm zoom (`scale: 1.02` over `400ms ease-out`).
- Details include category in `label-sm` (`#8C6239`), product title in `headline-sm`, and price in `title-md` (`#3E2723`).

### Chips & Filters
- **Default:** `#F4EFE6` background, `#3E2723` text, `0.25rem` radius, 1px border `#EADECE`.
- **Active:** `#3E2723` background, `#F9F6F0` text, border `#3E2723`.
- Used for materials (*Cuero Crudo*, *Suela Curtida*, *Plata 925*, *Apero Completo*).

### Input Fields & Selects
- Background `#FFFFFF`, border 1px solid `#D8DCD6`.
- Focus state replaces standard blue rings with a sharp 1.5px `#842A1C` outline accompanied by an ambient `#842A1C15` glow.
- Labels sit above the field in `label-md` uppercase, colored `#8C6239`.

### Checkboxes & Radio Buttons
- Custom square (`0.125rem` radius) or circle controls in `#D8DCD6` border.
- Checked state fills with `#842A1C` featuring a crisp ivory checkmark or pip.

### Specialty Equestrian Components
- **Stitch Border Divider:** Visual section separators featuring a central brass rivet or brand hallmark flanked by dashed leather stitch lines.
- **Leather Swatch Selector:** Square buttons displaying real hide grain textures with a delicate brass border on selection.
- **Origin Certificate Badge:** An authentic parchment-toned banner (`#EADECE`) with debossed typography marking master saddler certification.